## Snippets Module
**Custom file handlers and deployable ETL snippets for small projects**