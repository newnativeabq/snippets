import archives

a = archives.Archive()

a.set_format('zip')
print('format', a.format)
print('path', a.path)
