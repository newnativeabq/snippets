import os.path

from shutil import make_archive 
import tarfile

from functools import partial

import archive_builders

class Archive():
	def __init__(self, path=None, output_format=None, archive_name=None):
		if path == None:
			self.path = os.getcwd()
		else:
			self.path = path
		self.get_path(path)
		self.format = self.get_format_from_path()
		self.archive_name = archive_name

	def get_path(self, path):
		if path == None:
			self.path = os.getcwd()
		else:
			self.path = os.path.abspath(path)

	def get_format_from_path(self):
		return parse_format_from_path(self.path)

	def set_format(self, format):
		if format_is_valid(format):
			self.format = format
		else:
			print('Invalid Format')


def parse_format_from_path(path):
	path_as_str = str(path)
	path_as_str.split('.')[-1]


def file_exists(path):
	print('checking path', path)
	return os.path.exists(path)

def format_is_valid(format):
	builder_options = list(builder_menu.keys())
	scanner_options = list(scanner_menu.keys())

	if (format in builder_options) | (format in scanner_options):
		return True
	else:
		return False

def menu_lookup(format, menu):
	return menu[format]

builder_menu = {
	'bztar': partial(archive_builders.StandardBuilder, 'bztar'),
	'gztar': partial(archive_builders.StandardBuilder, 'gztar'),
	'tar': partial(archive_builders.StandardBuilder, 'tar'), 
	'xztar': partial(archive_builders.StandardBuilder, 'xztar'),
	'zip': partial(archive_builders.StandardBuilder, 'zip'),
}

scanner_menu = {
	'bztar': (None, 'bztar'),
	'gztar': (None, 'gztar'),
	'tar': (None, 'tar'), 
	'xztar': (None, 'xztar'),
	'zip': (None, 'zip'),
}